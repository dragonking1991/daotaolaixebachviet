<?php if(!defined('SOURCES')) die("Error");
	$dt_ret = ''; $__q = array();
	foreach(array('id_khoa','keyword','trang_thai','p') as $__k) if(isset($_GET[$__k]) && $_GET[$__k] !== '') $__q[$__k] = $_GET[$__k];
	if($__q) $dt_ret = '&'.http_build_query($__q);
	$__inc = isset($_GET['ret']) ? rawurldecode((string)$_GET['ret']) : '';
	$dat_ret = (strpos($__inc, 'index.php?com=daotao') === 0) ? rawurlencode($__inc) : rawurlencode('index.php?com=daotao&act=dat'.$dt_ret);
?>
<section class="content-header text-sm">
	<div class="container-fluid">
		<ol class="breadcrumb float-sm-left">
			<li class="breadcrumb-item"><a href="index.php">Bảng điều khiển</a></li>
			<li class="breadcrumb-item active">DAT (thực hành trên đường)</li>
		</ol>
	</div>
</section>
<section class="content">
	<div class="card card-primary card-outline text-sm">
		<div class="card-header">
			<h3 class="card-title"><strong>Tổng hợp DAT</strong> <span class="dt-count"><?=number_format((int)$total_items)?></span></h3>
			<div class="card-tools"><?php if(dt_can('dat','edit')): ?><button type="submit" form="dt-module-dat" onclick="return confirm('Xác nhận Đạt DAT thủ công cho học viên đã chọn?')" class="btn btn-sm bg-gradient-success"><i class="fas fa-check mr-1"></i>Đạt mục đã chọn</button> <a href="index.php?com=daotao&act=crudEdit&entity=dat" class="btn btn-sm bg-gradient-primary"><i class="fas fa-plus mr-1"></i>Thêm phiên</a> <?php endif; ?><?php if(dt_can('dat','import')): ?><a href="index.php?com=daotao&act=uploadDat<?=$id_khoa_sel?'&id_khoa='.$id_khoa_sel:''?>" class="btn btn-sm bg-gradient-success"><i class="fas fa-upload mr-1"></i>Import DAT</a> <?php endif; ?><?php if($id_khoa_sel && dt_can('dat','edit')): ?><a href="index.php?com=daotao&act=datDatAll&id_khoa=<?=$id_khoa_sel?>" onclick="return confirm('Đánh dấu ĐẠT DAT cho TẤT CẢ học viên trong khóa?')" class="btn btn-sm bg-gradient-warning"><i class="fas fa-check-double mr-1"></i>Đạt toàn bộ</a> <?php endif; ?><?php if(dt_can('dat','export')): ?><a href="<?=dt_export_link('exportDat', array('id_khoa','keyword','trang_thai'))?>" class="btn btn-sm bg-gradient-info"><i class="fas fa-file-excel mr-1"></i>Xuất Excel</a> <?php endif; ?></div>
		</div>
		<div class="card-body">
			<?php if(dt_can('dat','edit')): ?><form id="dt-module-dat" method="post" action="index.php?com=daotao&act=modulePassSelected"><input type="hidden" name="entity" value="dat"><input type="hidden" name="id_khoa" value="<?=(int)$id_khoa_sel?>"><input type="hidden" name="ret" value="<?=$dat_ret?>"></form><?php endif; ?>
			<form method="get" class="form-inline mb-2">
				<input type="hidden" name="com" value="daotao"><input type="hidden" name="act" value="dat">
				<select name="id_khoa" class="form-control form-control-sm mr-2" onchange="this.form.submit()">
					<option value="0">— Chọn khóa —</option>
					<?php foreach($ds_khoa as $k): ?><option value="<?=$k['id']?>" <?=$id_khoa_sel==$k['id']?'selected':''?>><?=htmlspecialchars(course_option_label($k))?></option><?php endforeach; ?>
				</select>
				<input type="text" name="keyword" class="form-control form-control-sm mr-2" placeholder="Tên / CCCD / Mã HV" value="<?=isset($_REQUEST['keyword'])?htmlspecialchars($_REQUEST['keyword']):''?>">
				<select name="trang_thai" class="form-control form-control-sm mr-2">
					<option value="">— Trạng thái —</option>
					<option value="dat" <?=(isset($_REQUEST['trang_thai'])&&$_REQUEST['trang_thai']=='dat')?'selected':''?>>Đủ điều kiện</option>
					<option value="chua" <?=(isset($_REQUEST['trang_thai'])&&$_REQUEST['trang_thai']=='chua')?'selected':''?>>Chưa đủ</option>
				</select>
				<button class="btn btn-sm bg-gradient-primary">Lọc</button>
			</form>
			<div class="dt-stats mb-2"><div class="dt-stat is-green"><div class="dt-stat-label">DAT đạt</div><div class="dt-stat-num"><?=(int)$module_stats['dat']?></div></div><div class="dt-stat is-red"><div class="dt-stat-label">DAT chưa đạt</div><div class="dt-stat-num"><?=(int)$module_stats['chua']?></div></div></div>
			<?php if(!empty($module_sync_result) && (!empty($module_sync_result['xd_added']) || !empty($module_sync_result['xd_course_updated']) || !empty($module_sync_result['errors']))): ?>
			<div class="alert alert-<?=empty($module_sync_result['ok'])?'danger':'info'?> py-2 mb-2" role="status"><?=htmlspecialchars(trim(xd_sync_training_notice($module_sync_result)),ENT_QUOTES,'UTF-8')?></div>
			<?php endif; ?>
			<?php if(!$id_khoa_sel && empty($items)): ?>
			<div class="alert alert-info mb-0">Chọn khóa để xem tổng hợp DAT, hoặc nhập CCCD/tên để tra cứu toàn bộ khóa.</div>
			<?php else: ?>
			<div class="table-responsive">
			<table class="table dt-list table-hover mb-0">
				<thead><tr><th class="text-center" style="width:34px"><?php if(dt_can('dat','edit')): ?><input type="checkbox" class="dt-bulk-all" data-form="dt-module-dat" title="Chọn tất cả"><?php endif; ?></th><th>Học viên</th><th>Tiến độ định mức</th><th>Phân bổ giờ &amp; phiên</th><th class="text-center">Điều kiện DAT</th></tr></thead>
				<tbody>
					<?php if(!empty($items)): foreach($items as $it):
						$hv=$it['hv']; $a=$it['agg']; $nguong=dt_nguong_dat(); $hangDat=dt_norm_hang($hv['hang']);
						$gioMucTieu=isset($nguong[$hangDat])?(float)$nguong[$hangDat]['a']:0;
						$kmMucTieu=isset($nguong[$hangDat])?(float)$nguong[$hangDat]['km']:0;
						$pctGio=$gioMucTieu>0?min(100,(int)round($a['a']/$gioMucTieu*100)):0;
						$pctKm=$kmMucTieu>0?min(100,(int)round($a['e']/$kmMucTieu*100)):0;
					?>
					<tr>
						<td class="text-center"><?php if(dt_can('dat','edit')): ?><input type="checkbox" class="dt-bulk-item" form="dt-module-dat" name="ids[]" value="<?=(int)$hv['id']?>"><?php endif; ?></td>
						<td>
							<div class="dt-title"><?=htmlspecialchars($hv['hoten'])?></div>
							<div class="dt-sub"><i class="fas fa-id-badge"></i><?=htmlspecialchars($hv['ma_hv'] ?: '—')?></div>
							<div class="dt-sub"><i class="fas fa-id-card"></i><?=htmlspecialchars($hv['cccd'])?><span class="dt-sep">•</span><span class="dt-tag is-muted"><?=htmlspecialchars($hv['hang'])?></span></div>
							<div class="dt-sub"><i class="fas fa-chalkboard-teacher"></i><?=htmlspecialchars(!empty($hv['gv_hoten']) ? $hv['gv_hoten'] : '—')?></div>
						</td>
						<td class="dt-dat-progress">
							<div class="dt-dat-progress-line"><span>Giờ thực hành</span><strong><?=$a['a']?><?php if($gioMucTieu): ?> / <?=$gioMucTieu?> giờ<?php else: ?> giờ<?php endif; ?></strong></div>
							<div class="dt-prog"><div class="dt-prog-bar"><span style="width:<?=$pctGio?>%"></span></div><span class="dt-prog-num"><?=$pctGio?>%</span></div>
							<div class="dt-dat-progress-line"><span>Quãng đường</span><strong><?=$a['e']?><?php if($kmMucTieu): ?> / <?=$kmMucTieu?> km<?php else: ?> km<?php endif; ?></strong></div>
							<div class="dt-prog"><div class="dt-prog-bar"><span style="width:<?=$pctKm?>%"></span></div><span class="dt-prog-num"><?=$pctKm?>%</span></div>
						</td>
						<td>
							<div class="dt-sub"><span class="dt-tag is-muted"><?=$it['so_phien']?> phiên</span><span class="dt-sep">•</span>Đêm <strong><?=$a['b']?> giờ</strong></div>
							<div class="dt-sub"><i class="fas fa-car"></i>Tự động <strong><?=$a['c']?> giờ</strong><span class="dt-sep">•</span>Số sàn <strong><?=$a['d']?> giờ</strong></div>
						</td>
						<td class="text-center"><?php if((int)$it['dat']===1): ?><span class="badge badge-success">Đủ điều kiện</span><?php if(!empty($it['override'])): ?> <span class="badge badge-warning">Xác nhận tay</span> <a href="index.php?com=daotao&act=datOverrideClear&id_khoa=<?=(int)$it['hv']['id_khoa']?>&cccd=<?=urlencode($it['hv']['cccd'])?>" onclick="return confirm('Bỏ xác nhận Đạt DAT cho học viên này?')" class="text-danger" title="Bỏ xác nhận"><i class="fas fa-times"></i></a><?php endif; ?><?php else: ?><span class="badge badge-danger">Chưa đủ</span><?php if(!empty($it['thieu'])): ?><div class="dt-sub mt-1 text-danger text-left"><?php foreach($it['thieu'] as $__t): ?><div><i class="fas fa-exclamation-circle"></i> <?=htmlspecialchars($__t)?></div><?php endforeach; ?></div><?php endif; ?><?php endif; ?></td>
					</tr>
					<?php endforeach; else: ?>
					<tr><td colspan="5" class="dt-empty"><div class="dt-empty-box"><i class="fas fa-road"></i><div>Chưa có dữ liệu DAT trong khóa này</div></div></td></tr>
					<?php endif; ?>
				</tbody>
			</table>
			</div>
			<?php endif; ?>
		</div>
			<?php if($id_khoa_sel && !empty($phien)): ?>
			<div class="mt-4"><div class="d-flex justify-content-between align-items-center mb-2"><h5 class="mb-0">Chi tiết phiên DAT</h5><?php if(dt_can('dat','delete')): ?><form id="dt-bulk-dat" method="post" action="index.php?com=daotao&act=crudDeleteSelected&entity=dat<?=$dt_ret?>"></form><button type="submit" form="dt-bulk-dat" class="btn btn-sm bg-gradient-danger dt-bulk-delete"><i class="fas fa-trash mr-1"></i>Xóa phiên đã chọn</button><?php endif; ?></div><div class="table-responsive"><table class="table dt-list table-hover mb-0"><thead><tr><th class="text-center" style="width:34px"><?php if(dt_can('dat','delete')): ?><input type="checkbox" class="dt-bulk-all" data-form="dt-bulk-dat" title="Chọn tất cả"><?php endif; ?></th><th>Phiên học</th><th>Thời gian</th><th>Quãng đường &amp; xe</th><th>Giáo viên</th><th class="dt-actions">Hành động</th></tr></thead><tbody><?php foreach($phien as $p): ?><tr><td class="text-center"><?php if(dt_can('dat','delete')): ?><input type="checkbox" class="dt-bulk-item" form="dt-bulk-dat" name="ids[]" value="<?=$p['id']?>"><?php endif; ?></td><td><div class="dt-title"><?=htmlspecialchars($p['ma_phien'])?></div><div class="dt-sub"><?=htmlspecialchars($p['ma_hv'])?></div></td><td><div class="dt-title"><?=!empty($p['ngay_hoc'])?date('d/m/Y',strtotime($p['ngay_hoc'])):'—'?></div><div class="dt-sub"><?=!empty($p['tg_batdau'])?date('H:i',strtotime($p['tg_batdau'])):'--:--'?> – <?=!empty($p['tg_ketthuc'])?date('H:i',strtotime($p['tg_ketthuc'])):'--:--'?></div></td><td><div class="dt-title"><?=htmlspecialchars($p['km'])?> km <span class="dt-sep">•</span><?=htmlspecialchars($p['gio_thuchanh'])?> giờ</div><div class="dt-sub"><span class="dt-tag is-muted"><?=htmlspecialchars($p['bien_so']?:'Chưa gán xe')?></span> <?=!empty($p['la_xe_tudong'])?'<span class="dt-tag">Tự động</span>':'<span class="dt-tag is-muted">Số sàn</span>'?></div></td><td class="dt-sub"><i class="fas fa-chalkboard-teacher"></i><?=htmlspecialchars($p['gv_hoten']?:'—')?></td><td class="dt-actions"><a href="index.php?com=daotao&act=crudEdit&entity=dat&id=<?=$p['id']?>&ret=<?=$dat_ret?>" class="btn btn-xs bg-gradient-info" title="Sửa"><i class="fas fa-edit"></i></a> <a href="index.php?com=daotao&act=crudDelete&entity=dat&id=<?=$p['id']?>&ret=<?=$dat_ret?>" class="btn btn-xs bg-gradient-danger dt-del" data-name="<?=htmlspecialchars($p['ma_phien'])?>" title="Xóa"><i class="fas fa-trash"></i></a></td></tr><?php endforeach; ?></tbody></table></div></div>
			<?php endif; ?>
	</div>
</section>
