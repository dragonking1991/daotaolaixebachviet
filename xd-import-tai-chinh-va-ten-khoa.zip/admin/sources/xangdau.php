<?php
if(!defined('SOURCES')) die("Error");

require_once LIBRARIES.'xangdau_config.php';

/* Các module chức năng của xăng dầu, được tách nhỏ để dễ bảo trì. */
require_once SOURCES.'xangdau/classes.php';
require_once SOURCES.'xangdau/permissions.php';
require_once SOURCES.'xangdau/schema.php';
require_once SOURCES.'xangdau/daotao_sync.php';
require_once SOURCES.'xangdau/ce.php';
require_once SOURCES.'xangdau/helpers.php';
require_once SOURCES.'xangdau/excel_cell.php';
require_once SOURCES.'xangdau/config.php';
require_once SOURCES.'xangdau/hoadon_crud.php';
require_once SOURCES.'xangdau/excel_convert.php';
require_once SOURCES.'xangdau/excel_stream.php';
require_once SOURCES.'xangdau/excel_open.php';
require_once SOURCES.'xangdau/hoadon_import.php';
require_once SOURCES.'xangdau/hocvien_crud.php';
require_once SOURCES.'xangdau/khoa.php';
require_once SOURCES.'xangdau/hocvien_import.php';
require_once SOURCES.'xangdau/hocvien_financial_import.php';
require_once SOURCES.'xangdau/algorithm.php';
require_once SOURCES.'xangdau/loc.php';
require_once SOURCES.'xangdau/export_list.php';
require_once SOURCES.'xangdau/export_quyettoan.php';
require_once SOURCES.'xangdau/export_excel.php';
require_once SOURCES.'xangdau/so_thanh_chu.php';
require_once SOURCES.'xangdau/export_tonghop.php';

switch($act)
{
	case 'khoa':
		if(xd_permission_denied($act)) $func->transfer('Bạn không có quyền vào trang này','index.php',false);
		xd_ensure_tables();xd_courses_page();$template='xangdau/khoa/items';break;
	case 'saveKhoa':
	case 'deleteKhoa':
		if(xd_permission_denied($act)) $func->transfer('Bạn không có quyền vào trang này','index.php',false);
		xd_ensure_tables();xd_course_save_action($act==='deleteKhoa');break;
	// ---- Cấu hình định mức ----
	case "config":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_get_config();
		$template = "xangdau/config/item_edit";
		break;
	case "saveConfig":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_save_config();
		break;
	case "xoaDieuChinhHocVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_xoa_dieu_chinh_hoc_vien();
		break;

	// ---- Hóa đơn XD ----
	case "hoadon":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_get_hoadon();
		$template = "xangdau/hoadon/items";
		break;
	case "uploadHoadon":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		$template = "xangdau/uploadHoadon/items";
		break;
	case "uploadHoadonExcel":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_upload_hoadon_excel();
		break;
	case "deleteHoadon":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_delete_hoadon();
		break;
	case "deleteHoadonSelected":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_delete_hoadon_selected();
		break;
	case "deleteAllHoadon":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_delete_all_hoadon();
		break;
	case "toggleKiemTraHoadon":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_toggle_kiem_tra_hoadon();
		break;
	case "toggleHopLeHoadon":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_toggle_hop_le_hoadon();
		break;

	// ---- Học viên XD ----
	case "hocvien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_get_hocvien();
		$template = "xangdau/hocvien/items";
		break;
	case "syncTrainingDat":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		$syncResult = xd_sync_training_students();
		$func->transfer("Đồng bộ học viên đạt DAT.".xd_sync_training_notice($syncResult), "index.php?com=xangdau&act=hocvien", !empty($syncResult['ok']));
		break;
	case "markImportedDat":
		if(xd_permission_denied($act) || !xd_can_import()) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_mark_imported_dat();
		break;
	case "ce":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_get_ce_data();
		$template = "xangdau/ce/items";
		break;
	case "ceInvoiceSave":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_ce_save_invoice();
		break;
	case "ceInvoiceUpload":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_ce_upload_invoices();
		break;
	case "ceInvoiceDelete":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_ce_delete_invoice();
		break;
	case "ceInvoiceTemplate":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_ce_invoice_template();
		break;
	case "uploadHocvien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		$template = "xangdau/uploadHocvien/items";
		break;
	case "uploadHocvienExcel":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		if(xd_upload_hocvien_excel()) $template = "xangdau/uploadHocvien/preview";
		break;
	case "deleteHocvien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_delete_hocvien();
		break;
	case "deleteHocvienSelected":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_delete_hocvien_selected();
		break;
	case "deleteHocvienByGv":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_delete_hocvien_by_gv();
		break;
	case "updateHocvienStatus":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_update_hocvien_status();
		break;
	case "updateHocvienInfo":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_update_hocvien_info();
		break;
	case "deleteAllHocvien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_delete_all_hocvien();
		break;

	// ---- Lọc thanh toán & bảng kê ----
	case "loc":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_loc_preview();
		$template = "xangdau/loc/items";
		break;
	case "xemGiaoVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_get_giao_vien_detail();
		$template = "xangdau/loc/detail";
		break;
	case "kiemTraGiaoVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_kiem_tra_giao_vien();
		break;
	case "huyKiemTraGiaoVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_huy_kiem_tra_giao_vien();
		break;
	case "duyetGiaoVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_duyet_giao_vien();
		break;
	case "duyetTatCaGiaoVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_duyet_tat_ca_giao_vien();
		break;
	case "huyDuyetGiaoVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_huy_duyet_giao_vien();
		break;
	case "locKiemTra":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_loc_kiem_tra();
		$template = "xangdau/loc/items_kiem_tra";
		break;
	case "locDuyet":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_loc_duyet();
		$template = "xangdau/loc/items_duyet";
		break;
	case "locDaThanhToan":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_loc_da_thanh_toan();
		$template = "xangdau/loc/items_dathanhtoan";
		break;
	case "xuatToanBoDanhSachHocVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_xuat_toan_bo_danh_sach_hoc_vien();
		break;
	case "xuatTongHopDaDuyet":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_xuat_tong_hop_da_duyet();
		break;
	case "xuatHoadonExcel":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_xuat_hoadon_excel();
		break;
	case "xuatHocvienExcel":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_xuat_hocvien_excel();
		break;
	case "xuatTatCaBangKe":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_xuat_tat_ca_bang_ke();
		break;
	case "xuatTongHopGiaoVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_xuat_tong_hop_giao_vien();
		break;
	case "xuatDaKiemTraGiaoVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_xuat_da_kiem_tra_giao_vien();
		break;
	case "xuatBangKeGiaoVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_xuat_bangke_giao_vien();
		break;
	case "xuatBangKeDaDuyetGiaoVien":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_xuat_bangke_da_duyet_giao_vien();
		break;
	case "xuatBangKe":
		if(xd_permission_denied($act)) $func->transfer("Bạn không có quyền vào trang này", "index.php", false);
		xd_ensure_tables();
		xd_xuat_bangke();
		break;

	default:
		$func->redirect("index.php?com=xangdau&act=config");
}
